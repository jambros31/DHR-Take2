﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace DHR_Take2.Models
{
    public class PatientDB : DbContext
    {
        public DbSet<UserAccount> UserAccount { get; set; }
    }
}