﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DHR_Take2.Models;

namespace DHR_Take2.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            using (PatientDB db = new PatientDB())
            {
                return View(db.UserAccount.ToList());
            }
        }

        public ActionResult Register()
        //This will show the emtpy fields registration page
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(UserAccount account)
        {
            if (ModelState.IsValid)
            {
                using (PatientDB db = new PatientDB())
                {
                    db.UserAccount.Add(account);
                    db.SaveChanges();
                }
                ModelState.Clear(); //Clears input fields
                ViewBag.Message = "You have successfully registered " + account.FirstName + " " + account.LastName;
            }
            return View();
        }

        //Login
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(UserAccount user)
        {
            using (PatientDB db = new PatientDB())
            {
                var usr = db.UserAccount.SingleOrDefault(u => u.Username == user.Username && u.Password == user.Password);
                if (usr != null)
                {
                    Session["UserID"] = usr.UserID.ToString();
                    Session["Username"] = usr.Username.ToString();
                    return RedirectToAction("LoggedIn");
                }
                //If Login Fails
                else

                {
                    ModelState.AddModelError("", "Invalid UserName or Password, Please check entries");
                }
                
            }
            return View();
        }

        public ActionResult LoggedIn()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

    }
}